import numpy as np
import math

def nCr(n, r):
    return math.factorial(n) // math.factorial(r) // math.factorial(n-r)

def get_likelihood(head_counts, tail_counts, theta):
    nCr_vectorized = np.vectorize(nCr)
    return nCr_vectorized(10, head_counts) * (theta ** head_counts) * ((1 - theta) ** tail_counts)

def get_coins_expected_flips(counts, likelihood):
    return sum(list(i*j for i, j in zip (counts, likelihood)))

def main():
    head_counts, tail_counts = np.array([5, 9, 8, 4, 7]), 10 - np.array([5, 9, 8, 4, 7])

    # E-step : Guessing parameters
    theta_a, theta_b = 0.6, 0.5

    #M-step: Maximize
    while True:
        a, b = get_likelihood(head_counts, tail_counts, theta_a), get_likelihood(head_counts, tail_counts, theta_b)

        likelihood_a, likelihood_b = a / (a + b), b / (a + b)

        coin_a_head, coin_a_tail = get_coins_expected_flips(head_counts, likelihood_a), get_coins_expected_flips(tail_counts, likelihood_a) 
        coin_b_head, coin_b_tail = get_coins_expected_flips(head_counts, likelihood_b), get_coins_expected_flips(tail_counts, likelihood_b) 

        theta_a_prev, theta_b_prev = theta_a, theta_b

        #update params
        theta_a, theta_b = coin_a_head / (coin_a_head + coin_a_tail), coin_b_head / (coin_b_head + coin_b_tail)
        if(abs(theta_a - theta_a_prev) <= 0.001 and abs(theta_b - theta_b_prev) <= 0.001):
            break
    print('Theta_a: ' + str(theta_a))
    print('Theta_b: ' + str(theta_b))


if __name__ == '__main__':
    main()