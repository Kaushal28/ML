#Simple linear regression using stochastic gradient descent
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def abline(slope, intercept):
    """Plot a line from slope and intercept"""
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')

#y = mx + b
#m is slope, b is y-intercept
#Change the learning rate and see how algorithm diverges.
def linear_regression(X, y, m_current=0 , b_current=0, iterations=100000, learning_rate=0.00000001):
    N = float(len(X))
    for i in range(iterations):
        y_current = m_current * X + b_current
        cost = np.sum([data**2 for data in (y-y_current)])/N
        m_gradient = -(2/N)*np.sum(X*(y-y_current))
        b_gradient = -(2/N)*np.sum(y-y_current)
        m_current = m_current - learning_rate * m_gradient
        b_current = b_current -  learning_rate * b_gradient

    return m_current, b_current, cost

def run():
    #get training data
    data = np.genfromtxt("datasets/data1.csv", delimiter=",")
    x = np.array(data)[:,0]
    y = np.array(data)[:,1]

    m, b, cost = linear_regression(x[1:], y[1:])
    print('m: ' + str(m))
    print('b: ' + str(b))
    print('Cost: ' + str(cost))
    print(m*100 + b)
    plt.plot(x, y, 'ro')
    abline(m, b)
    plt.show()

if __name__ == '__main__':
    run()
