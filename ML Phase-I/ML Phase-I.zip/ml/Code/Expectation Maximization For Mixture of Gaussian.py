#EM (Expectation Maximization Algorithm)
import numpy as np
from scipy import stats

np.random.seed(110)

red_mean, red_std = 3, 0.8

blue_mean, blue_std = 7, 2

red = np.random.normal(red_mean, red_std, size = 20)
blue = np.random.normal(blue_mean, blue_std, size=20)

both_colours = np.sort(np.concatenate((red, blue)))

red_mean_guess, red_std_guess = 1.1, 2
blue_mean_guess, blue_std_guess = 9, 1.7

def estimate_mean(data, weight):
    return np.sum(data*weight) / np.sum(weight)

def estimate_std(data, weight, mean):
    variance = np.sum(weight * (data-mean)**2) / np.sum(weight)
    return np.sqrt(variance)

for i in range (25):
    likelihood_of_red = stats.norm(red_mean_guess, red_std_guess).pdf(both_colours)
    likelihood_of_blue = stats.norm(blue_mean_guess, blue_std_guess).pdf(both_colours)

    red_weight = likelihood_of_red / (likelihood_of_blue + likelihood_of_red)
    blue_weight = likelihood_of_blue / (likelihood_of_blue + likelihood_of_red)

    blue_std_guess = estimate_std(both_colours, blue_weight, blue_mean_guess)
    red_std_guess = estimate_std(both_colours, red_weight, red_mean_guess)

    red_mean_guess = estimate_mean(both_colours, red_weight)
    blue_mean_guess = estimate_mean(both_colours, blue_weight)

print ('RED mean guess: ' + str(red_mean_guess) + ' Actual mean: ' + str(np.mean(red)))
print ('RED std guess: ' + str(red_std_guess) + ' Actual std: ' + str(np.std(red)))
print ('BLUE mean guess: ' + str(blue_mean_guess) + ' Actual mean: ' + str(np.mean(blue)))
print ('BLUE std guess: ' + str(blue_std_guess) + ' Actual std: ' + str(np.std(blue)))

