import numpy as np

np.random.seed(110)
x = np.random.randint(1, 4999, size=1000)
for rand in x:
    if('4' in str(rand)):
        with open('datasets/data1.csv', 'a') as f:
            f.write(str(rand) + ',' + str(rand).replace('4', '5') + '\n')
    else:
        with open('datasets/data1.csv', 'a') as f:
            f.write(str(rand)+ ',' + str(rand) +'\n')
