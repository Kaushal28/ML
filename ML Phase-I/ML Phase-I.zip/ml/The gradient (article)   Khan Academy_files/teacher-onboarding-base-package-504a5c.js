KAdefine("javascript/teacher-onboarding-base-package/demo-class-decider.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var isDemoClassRoute=false
var isDemoClass=exports.isDemoClass=function e(){return isDemoClassRoute}
var setIsDemoClassRoute=exports.setIsDemoClassRoute=function s(e){return isDemoClassRoute=e}
});
